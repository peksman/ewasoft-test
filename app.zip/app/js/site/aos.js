export function initAos() {
    let aosInitialized = false;

    function initAOS() {
        if (!aosInitialized && window.innerWidth > 768) {
            AOS.init({
                once: true,
            });
            aosInitialized = true;
        }
    }

    window.onload = initAOS;
    window.addEventListener('resize', initAOS);
}