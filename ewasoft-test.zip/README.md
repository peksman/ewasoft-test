# ewasoft-test
FRONTEND DEVELOPER competency test

# Steps to install project:
# 1. Ensure you have Node.js version 12.0.0 installed (if not, install it and then proceed to step 4).
# 2. Download and install Node.js version 12.0.0 from https://nodejs.org/en/blog/release/v12.0.0
# 3. After installing, switch to version 12.0.0.
# 4. In the project root, open the terminal and run npm install.
# 5. Once the installation is complete, run gulp watch and wait for the project to synchronize with your browser.
# 6. Happy coding!